# RouteOps Cloud — Prototype

A high-fidelity, clickable prototype of **RouteOps Cloud**, a browser-based
strategic route planning portal for **Community Coffee**. It is a modern cloud
replacement for a legacy on-prem desktop route planning tool, used by a routing
analyst to plan delivery routes one market at a time.

It is **not** a live delivery / fleet / shipment tracking app. It is a
grid-first, map-supported planning tool used *before* routes go live.

## Main workflow

Dashboard → Upload / Ingest → Data Preview + Compare Summary → Commit Ingest →
Create Session → Session Management Grid View → Create Option 1 → Map / Lasso
View → Lasso Selection → Bulk Move Preview → Apply Move → Route Balancing →
Proposed Moves Review → Accept Moves → Final Metrics Review → Finalize Option →
Export Stop List → Export Complete.

## Tech

Pure static front end — no build step, no dependencies:

- `index.html` — app shell (sidebar, top bar, modals)
- `styles.css` — design system (dark sidebar, yellow accents, cards, tables, map)
- `app.js` — all screens, navigation, and interactions (vanilla JS)

## Run locally

Any static file server works. For example:

```bash
# Python 3
python -m http.server 3000
# then open http://localhost:3000

# or Node
npx serve .
```

Open the served URL in a desktop browser (designed for ~1440px wide).

---

## Create the GitHub repo and push (run these on your machine)

Download / copy this `routeops-cloud` folder locally first, then:

### Option A — GitHub CLI (easiest)

```bash
cd routeops-cloud
git init
git add .
git commit -m "RouteOps Cloud prototype"
gh repo create YOUR_USERNAME/routeops-cloud --public --source=. --push
```

Replace `YOUR_USERNAME` and use `--private` instead of `--public` if you prefer.

### Option B — plain git (create the empty repo in the GitHub UI first)

1. On github.com, create a new **empty** repository named `routeops-cloud`
   (no README, no .gitignore, no license).
2. Then:

```bash
cd routeops-cloud
git init
git add .
git commit -m "RouteOps Cloud prototype"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/routeops-cloud.git
git push -u origin main
```
